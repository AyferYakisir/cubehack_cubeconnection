import 'package:flutter/material.dart';

class MeetingCreateModel {
  final int? selectedTable;
  final TimeOfDay? selectedTime;

  MeetingCreateModel({this.selectedTable, this.selectedTime});
}
