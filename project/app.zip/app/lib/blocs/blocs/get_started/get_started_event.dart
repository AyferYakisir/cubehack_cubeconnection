abstract class GetStartedEvent {}

class GetStartedButtonPressed extends GetStartedEvent {}
