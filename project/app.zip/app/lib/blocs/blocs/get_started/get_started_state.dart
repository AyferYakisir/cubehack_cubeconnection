abstract class GetStartedState {}

class GetStartedInitial extends GetStartedState {}

class GetStartedNavigating extends GetStartedState {}
