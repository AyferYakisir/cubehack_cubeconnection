abstract class HomeEvent {}

class LoadInitiatives extends HomeEvent {}
