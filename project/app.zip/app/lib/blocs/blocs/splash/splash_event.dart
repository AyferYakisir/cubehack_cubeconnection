abstract class SplashEvent {}

class SplashStarted extends SplashEvent {}
