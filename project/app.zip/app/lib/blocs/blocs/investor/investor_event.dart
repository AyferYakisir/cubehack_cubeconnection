abstract class InvestorEvent {}

class LoadInvestments extends InvestorEvent {}
