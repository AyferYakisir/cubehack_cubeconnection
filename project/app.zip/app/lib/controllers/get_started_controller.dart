class GetStartedController {
  void onStart() {
    // Gerekirse loglama yapılır
    print("Get Started pressed");
  }
}
