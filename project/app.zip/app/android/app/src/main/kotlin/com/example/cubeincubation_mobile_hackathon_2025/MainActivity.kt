package com.example.cubeincubation_mobile_hackathon_2025

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
